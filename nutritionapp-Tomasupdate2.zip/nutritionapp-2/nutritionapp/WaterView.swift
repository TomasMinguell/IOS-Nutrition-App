//
//  WaterView.swift
//  nutritionapp
//
//  Created by Minguell, Tomas P on 4/26/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit

@IBDesignable class WaterView: UIView {
    
    private struct Constants {
        //We will change this to equal the water goal that the user enters
        static let numberOfGlasses = 8
        static let lineWidth: CGFloat = 5.0
        static let arcWidth: CGFloat = 10
        
        static var halfOfLineWidth: CGFloat {
            return lineWidth / 2
        }
    }

    @IBInspectable var counter: Int = 5 {
        didSet {
            if counter <= Constants.numberOfGlasses {
                //the view needs to be refreshed
                setNeedsDisplay()
            }
        }
    }
    @IBInspectable var sineLineColor: UIColor = UIColor.blue
    @IBInspectable var glassColor: UIColor = UIColor.black
    
    override func draw(_ rect: CGRect) {
        
        let width = self.frame.size.width
        let height = self.frame.size.height
        
        // 4
        let path = UIBezierPath()
        
        path.move(to: CGPoint(x: 0.0, y: 0.0))
        
        path.addLine(to: CGPoint(x: 50.0, y: height))
        
        path.addLine(to: CGPoint(x: width-50, y: height))
        
        path.addLine(to: CGPoint(x: width, y: 0.0))
        
        path.close()
        
        // 5
        path.lineWidth = Constants.arcWidth
        glassColor.setStroke()
        path.stroke()
        
        let sineOrigin = CGPoint(x: (width-50) * (1 - 0.70) / 2, y: height / 2)
        
        let sinePath = UIBezierPath()
        sinePath.move(to: sineOrigin)
        
        for angle in stride(from: 5.0, through: 360.0, by: 5.0) {
            let x = sineOrigin.x + CGFloat(angle/360.0) * width * 0.8
            let y = sineOrigin.y - CGFloat(sin(angle/180.0 * Double.pi)) * height * 0.02
            sinePath.addLine(to: CGPoint(x: x, y: y))
        }
        
        sineLineColor.setStroke()
        sinePath.stroke()
    }
}
