//
//  ViewController.swift
//  nutritionapp
//
//  Created by Yun, Yeji on 4/22/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit


class ViewController: UIViewController{
    
 
    var counter = 0
    
    //@IBOutlet weak var waterView: WaterView!
    //@IBOutlet weak var goal: GoalsViewController!
    
    @IBOutlet weak var waterLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        //var counter = waterView.counter
        //var waterGoal = goal.waterGoalNum
        
        func dataReady(type: Int) {
            self.waterLabel.text = "glasses of water drunk today."

        // Do any additional setup after loading the view, typically from a nib.
    }

        func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        }
    }
}
