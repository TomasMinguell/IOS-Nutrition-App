//
//  ViewController.swift
//  nutritionapp
//
//  Created by Yun, Yeji on 4/22/19.
//  Copyright © 2019 Yun, Yeji. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var waterView: WaterView!
    @IBOutlet weak var waterLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if waterView?.counter != nil {
            let text = String(waterView!.counter)
            self.waterLabel.text = text + "/8 glasses of water drunk!"
        } else {
            self.waterLabel.text = "No water drunk today!"
        }
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

