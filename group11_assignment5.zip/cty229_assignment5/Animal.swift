//
//  Animal.swift
//  cty229_assignment5
//
//  Created by Catarina Yee on 3/1/19.
//  Copyright © 2019 Catarina Yee. All rights reserved.
//

import Foundation

class Animal {
    
    var name = "Default"
    var sciName = "Default"
    var className = "Default"
    var size = 0.0
    var image = "Default"

    init(name:String, sciName:String, className:String, size:Double, image:String) {
        self.name = name
        self.sciName = sciName
        self.className = className
        self.size = size
        self.image = image
    }

}

let cat = Animal(name:"Cat", sciName: "Felis catus", className: "Mammalia", size:4.0, image:"loaf")
let ocelot = Animal(name: "Ocelot", sciName: "Leopardus pardalis", className: "Mammalia", size: 12.0, image: "ocelot")
let leopard = Animal(name: "Leopard", sciName: "Panthera pardus", className: "Mammalia", size: 60.0, image: "leopard")
let bird = Animal(name: "Cardinal", sciName: "Cardinalis cardinalis", className: "Aves", size: 0.045, image: "bird")

let animalList = [bird, cat, leopard, ocelot]

