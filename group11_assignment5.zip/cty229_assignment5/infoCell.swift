//
//  infoCell.swift
//  cty229_assignment5
//
//  Created by Catarina Yee on 3/5/19.
//  Copyright © 2019 Catarina Yee. All rights reserved.
//

import UIKit

class infoCell: UITableViewCell {

    @IBOutlet weak var sciNameLabel: UILabel!
    @IBOutlet weak var classNameLabel: UILabel!
    @IBOutlet weak var sizeLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

