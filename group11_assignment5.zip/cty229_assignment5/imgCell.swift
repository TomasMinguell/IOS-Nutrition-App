//
//  imgCell.swift
//  cty229_assignment5
//
//  Created by Catarina Yee on 3/5/19.
//  Copyright © 2019 Catarina Yee. All rights reserved.
//

import UIKit

class imgCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var animalPic: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}



