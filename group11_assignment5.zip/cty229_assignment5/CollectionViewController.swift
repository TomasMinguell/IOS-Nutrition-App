//
//  CollectionViewController.swift
//  cty229_assignment5
//
//  Created by Catarina Yee on 3/6/19.
//  Copyright © 2019 Catarina Yee. All rights reserved.
//

import UIKit

class CollectionViewController: UICollectionViewController {
    private let reuseIdentifier = "collectViewCell"

    var animalPics = [String]()
    var animalCaptions = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        accessGalleryItemPlist()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // Not sure how the plist stuff workds but here's where im working on it
    private func accessGalleryItemPlist() {
        let sourceFile = Bundle.main.path(forResource: "GalleryItem", ofType: "plist")
        let animalPicArray = NSArray(contentsOfFile: sourceFile!)
        for item in animalPicArray as! [Dictionary<String, String>] {
            for (key, value) in item {
                animalPics.append(key)
                animalPics.sort()
                animalCaptions.insert(value, at: animalPics.index(where: {$0 == key})!)
            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

    // MARK: UICollectionViewDataSource

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 12
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectViewCell", for: indexPath) as! CollectionViewCell
        cell.collectViewImg.image = UIImage(named: animalPics[indexPath.row])
        cell.collectViewLabel.text = animalCaptions[indexPath.row]
//        let imageview:UIImageView = UIImageView(frame: CGRect(x: -25, y: 0, width: 300, height: 200));
//        let img:UIImage = UIImage(named: animalPics[indexPath.row])!
//        imageview.image = img
//        cell.contentView.addSubview(imageview)
        
        return cell

    }
    
    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionElementKindSectionHeader, withReuseIdentifier: "header", for: indexPath)
        let footer = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionElementKindSectionFooter, withReuseIdentifier: "footer", for: indexPath)
    
        if kind == UICollectionElementKindSectionFooter {
            return footer
        }
        else {
            return header
        }
    }
    

    func configureCellImage(cell: UICollectionViewCell, forItemAtIndexPath: IndexPath, imageName: String) {
        let imageView = UIImageView(image: UIImage(named: imageName))
        imageView.contentMode = .scaleAspectFit
        cell.addSubview(imageView)
    }
    // MARK: UICollectionViewDelegate

    /*
    // Uncomment this method to specify if the specified item should be highlighted during tracking
    override func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment this method to specify if the specified item should be selected
    override func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
    override func collectionView(_ collectionView: UICollectionView, shouldShowMenuForItemAt indexPath: IndexPath) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, canPerformAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, performAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) {
    
    }
    */

}
