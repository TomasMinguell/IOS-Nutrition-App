//
//  CollectionViewCell.swift
//  cty229_assignment5
//
//  Created by Catarina Yee on 3/8/19.
//  Copyright © 2019 Catarina Yee. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var collectViewImg: UIImageView!
    @IBOutlet weak var collectViewLabel: UILabel!
    
}
